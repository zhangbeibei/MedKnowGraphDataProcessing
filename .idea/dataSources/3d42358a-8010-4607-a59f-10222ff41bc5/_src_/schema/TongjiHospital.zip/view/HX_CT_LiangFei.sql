CREATE VIEW HX_CT_LiangFei AS
  SELECT
    `TongjiHospital`.`V_YCC_DICOMSTUDY`.`PATIENTID`      AS `PATIENTID`,
    `TongjiHospital`.`XY_RIS_REPORT`.`APPLY_TIME`        AS `APPLY_TIME`,
    `TongjiHospital`.`XY_RIS_REPORT`.`EXAMINE_NAME`      AS `EXAMINE_NAME`,
    `TongjiHospital`.`XY_RIS_REPORT`.`EXAMINE_TYPE`      AS `EXAMINE_TYPE`,
    `TongjiHospital`.`XY_RIS_REPORT`.`IMAGING_FINDING`   AS `IMAGING_FINDING`,
    `TongjiHospital`.`XY_RIS_REPORT`.`EXAMINE_DIAGNOSIS` AS `EXAMINE_DIAGNOSIS`
  FROM `TongjiHospital`.`XY_TEMP`
    JOIN `TongjiHospital`.`V_YCC_DICOMSTUDY`
    JOIN `TongjiHospital`.`XY_RIS_REPORT`
  WHERE ((`TongjiHospital`.`XY_TEMP`.`CARD_NO` = `TongjiHospital`.`V_YCC_DICOMSTUDY`.`PATIENTID`) AND
         (`TongjiHospital`.`XY_RIS_REPORT`.`PATIENT_ID` = `TongjiHospital`.`XY_TEMP`.`PATIENT`) AND
         (`TongjiHospital`.`XY_RIS_REPORT`.`APPLY_TIME` BETWEEN 20150101 AND 20150430) AND
         (`TongjiHospital`.`XY_RIS_REPORT`.`EXAMINE_DIAGNOSIS` LIKE '%两肺%') AND
         (`TongjiHospital`.`XY_RIS_REPORT`.`EXAMINE_TYPE` = 'CT'))
  ORDER BY `TongjiHospital`.`XY_RIS_REPORT`.`APPLY_TIME`;
